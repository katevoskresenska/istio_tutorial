#!/bin/bash

kubectl delete all --all -n istio-course