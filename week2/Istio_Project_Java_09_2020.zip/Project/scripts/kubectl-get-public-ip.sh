#!/bin/bash

kubectl get svc istio-ingressgateway -n istio-system